[33mcommit 3707458c7fd444aa461394f5dd6b23125e53ab70[m
Merge: ab66433 5ac93ce
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Fri Nov 19 12:31:28 2021 -0700

    Merge pull request #12 from CU-CSCI-3308-Fall-2021/route.js_overhaul
    
    Route.js overhaul

[33mcommit 5ac93ce64ee6cd7a7562706f004e577e67c8542e[m[33m ([m[1;31morigin/route.js_overhaul[m[33m)[m
Merge: f9353fc ab66433
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Fri Nov 19 12:30:49 2021 -0700

    Merge branch 'main' into route.js_overhaul

[33mcommit f9353fcd6f415472f185d67149bda7d5125caeeb[m[33m ([m[1;32mroute.js_overhaul[m[33m)[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Fri Nov 19 12:16:01 2021 -0700

    Fixed itgit add .git add .git add .

[33mcommit 37670e0f86eb1eb25e81c6ad0b8a17ba22b2ae6b[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Fri Nov 19 11:37:19 2021 -0700

    works until backend breaks

[33mcommit 2d84341f63ea320c06b44301497f658b2740d3a4[m
Merge: 0cc7dbe 080272d
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Thu Nov 18 18:12:54 2021 -0700

    Merge pull request #11 from CU-CSCI-3308-Fall-2021/route.js_overhaul
    
    fixed button

[33mcommit 080272d37da48ecdb6aa923b610c2905cae6485b[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Thu Nov 18 18:12:20 2021 -0700

    fixed button

[33mcommit d3a79a258bd241a683480c1b301fa002c58389fe[m
Merge: 675b9ab e5768f0
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Thu Nov 18 17:59:44 2021 -0700

    Merge pull request #10 from CU-CSCI-3308-Fall-2021/route.js_overhaul
    
    Route.js overhaul

[33mcommit e5768f0ecc50f0547a5726051be5a28fbf609c5e[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Thu Nov 18 17:58:45 2021 -0700

    kinda broken but whatever

[33mcommit b8f48a3dfeb1305fa283ccd6d0d80d02c8a5e0ca[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Thu Nov 18 17:28:13 2021 -0700

    fixing I think

[33mcommit 7a0ae90cef505bec4b68259b08e1230bec01e96a[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Tue Nov 16 00:22:29 2021 -0700

    user-specific favorite routes

[33mcommit 47925eb795856448335b07be8bfd79e03a8721c4[m[33m ([m[1;31morigin/BackendUpdate[m[33m, [m[1;32mBackendUpdate[m[33m)[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Mon Nov 15 18:53:06 2021 -0700

    better session storage

[33mcommit 23da439141042e3ed228612fd990bed525e4d22c[m
Merge: 15bdcc1 beac5d0
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Mon Nov 15 18:50:54 2021 -0700

    Merge branch 'main' of https://github.com/CU-CSCI-3308-Fall-2021/CSCI-3308-Fall21-017-03 into BackendUpdate

[33mcommit 15bdcc1c43da3643a4b6444579929a686cc5ec8a[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Mon Nov 15 18:50:42 2021 -0700

    messy session storage

[33mcommit bc673cb669f10d0ed58dedee23a080badf2be955[m
Merge: 286313b 13b4473
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Mon Nov 15 15:39:19 2021 -0700

    Merge pull request #7 from CU-CSCI-3308-Fall-2021/BackendUpdate
    
    Backend update

[33mcommit 13b44735728b5e6a2af6f73c3b3734874a50bccc[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Mon Nov 15 15:38:37 2021 -0700

    Added favorite routes endpoint

[33mcommit 49d80bf138044f0594a1ddeee4d1c68c5a9e48e1[m
Merge: aa97516 286313b
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Mon Nov 15 12:01:25 2021 -0700

    Fixed discrepency

[33mcommit aa97516f80b96f795ecaba06d24a51d84c99c35a[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Mon Nov 15 11:55:48 2021 -0700

    Backend before favRoutes

[33mcommit 0983fa939f81f4402264198e12ec03f8437f12f9[m
Merge: 5be703e 3044ab1
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Sun Nov 14 19:09:05 2021 -0700

    Merge pull request #6 from CU-CSCI-3308-Fall-2021/BackendUpdate
    
    Backend update

[33mcommit 3044ab134000aef95827208f4c2d6098026872ec[m
Merge: 0c5f460 5be703e
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Sun Nov 14 19:07:45 2021 -0700

    Fixed conflict with last build

[33mcommit 0c5f4600bf26f4641172da890b16a7aa090fb27c[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Sun Nov 14 18:58:54 2021 -0700

    Added update user and (almost complete) feedback endpoints

[33mcommit 0377c597a65297678536bb764ad5db07af5a0d2b[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Sun Nov 14 10:37:05 2021 -0700

    halfway build

[33mcommit 19ed68ff8399bf6e902cf25dc3b393967c2b982b[m
Merge: ae7cf23 e193431
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Sun Nov 7 12:47:33 2021 -0700

    Merge pull request #4 from CU-CSCI-3308-Fall-2021/BackendUpdate
    
    Backend update

[33mcommit e1934313c6cde60a7875a30060e4a05344f4112c[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Sun Nov 7 12:47:01 2021 -0700

    Added new login endpoint and ensured new users are unique

[33mcommit 366d952647a785058d4e20ebe60ea40d4416e948[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Wed Nov 3 14:21:49 2021 -0600

    Added documentation

[33mcommit 2c2df9373bb71767d4ddeb1ec20b34933745b383[m
Merge: 45feaff 56d32ff
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Sun Oct 31 18:33:38 2021 -0600

    Merge pull request #3 from CU-CSCI-3308-Fall-2021/BackendUpdate
    
    shifted database to postgres

[33mcommit 56d32ffe35a7e03ee6c6bef0130b3b6333842d90[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Sun Oct 31 18:31:42 2021 -0600

    shifted database to postgres

[33mcommit 14ceaaf1205dab52f81a5cfcd49fd6a4c95b28c2[m
Merge: 4246b85 83b1dcc
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Sun Oct 10 23:33:13 2021 -0600

    Merge pull request #2 from CU-CSCI-3308-Fall-2021/BackendUpdate
    
    adding backend work

[33mcommit 83b1dcc847d5a1d3129b375d7181d82802677b8b[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Sun Oct 10 23:30:27 2021 -0600

    adding backend word

[33mcommit c83dcc68eb65d844919b3b26ee884b980dd92f8c[m
Merge: e403d90 307eae4
Author: Owen Helfer <89760648+OwenHelfer@users.noreply.github.com>
Date:   Fri Oct 1 21:39:23 2021 -0600

    Merge pull request #1 from CU-CSCI-3308-Fall-2021/owensBranch
    
    pushing research

[33mcommit 307eae4eb43582265cd486f46c0851e14a02944e[m[33m ([m[1;31morigin/owensBranch[m[33m)[m
Author: OwenHelfer <owhe5534@colorado.edu>
Date:   Fri Oct 1 21:37:05 2021 -0600

    pushing research
